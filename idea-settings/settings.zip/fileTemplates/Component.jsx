import React from 'react';


const ${NAME} = (props) => {
  return (
      <div>#[[$END$]]#
      </div>
  );
};

export default ${NAME};