import React from 'react';
import classes from "./${NAME}.module.css";

const ${NAME} = (props) => {
  return (
      <div className={classes.${NAME}}>#[[$END$]]#
      </div>
  );
};

export default ${NAME};