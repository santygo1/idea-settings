#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")

import lombok.Getter;
import org.springframework.http.HttpStatus;

@Getter
public abstract class ResponseStatusException extends RuntimeException{

    private final HttpStatus httpStatus;

    public ResponseStatusException(String errorMessage, HttpStatus httpStatus){
        super(errorMessage);
        this.httpStatus = httpStatus;
    }
}