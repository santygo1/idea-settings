#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")

#set($NAME_LOWER = $NAME.toLowerCase())
#set($SERVICE_TYPE = "${NAME}Service")
#set($SERVICE_VARIABLE = "${NAME_LOWER}Service")
#set($SERVICE = "$SERVICE_TYPE $SERVICE_VARIABLE")
#set($MODEL = "${NAME}Entity")

import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import ${PACKAGE_NAME}.entity.${MODEL};
import ${PACKAGE_NAME}.service.${SERVICE_TYPE};

import java.net.URI;

@RestController
@RequestMapping("/${NAME_LOWER}s")
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class ${NAME}Controller {
    
    ${SERVICE};

    @GetMapping
    public ResponseEntity<Iterable<${MODEL}>> get${NAME}List() {
        Iterable<${MODEL}> list = ${SERVICE_VARIABLE}.get${NAME}List();

        return ResponseEntity.ok(list);
    }

    @GetMapping("/{${NAME_LOWER}Id}")
    public ResponseEntity<${MODEL}> get${NAME}ById(@PathVariable Long ${NAME_LOWER}Id) {
        ${MODEL} ${NAME_LOWER} = ${SERVICE_VARIABLE}.get${NAME}(${NAME_LOWER}Id);

        return ResponseEntity.ok(${NAME_LOWER});
    }


    @PostMapping
    public ResponseEntity<${MODEL}> create${NAME}(@RequestBody ${MODEL} ${NAME_LOWER}ToCreate) {
        ${MODEL} created${NAME} =${SERVICE_VARIABLE}.create${NAME}(${NAME_LOWER}ToCreate);

        URI location = ServletUriComponentsBuilder
                .fromCurrentRequest()
                .path("/{id}")
                .buildAndExpand(created${NAME}.getId())
                .toUri();

        return ResponseEntity
                .created(location)
                .body(created${NAME});
    }

    @PutMapping("/{${NAME_LOWER}Id}")
    public ResponseEntity<${MODEL}> update${NAME}(
            @PathVariable Long ${NAME_LOWER}Id,
            @RequestBody ${MODEL} ${NAME_LOWER}ToUpdate) {

        ${MODEL} updated${NAME} = ${SERVICE_VARIABLE}.replace${NAME}(${NAME_LOWER}Id, ${NAME_LOWER}ToUpdate);

        return ResponseEntity.ok(updated${NAME});
    }

    @DeleteMapping("/{${NAME_LOWER}Id}")
    public ResponseEntity<Void> delete${NAME}ById(@PathVariable Long ${NAME_LOWER}Id) {
        ${SERVICE_VARIABLE}.delete${NAME}(${NAME_LOWER}Id);
        return ResponseEntity.noContent().build();
    }
    
}