#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")

#set($NAME_LOWER = $NAME.toLowerCase())
#set($MODEL = "${NAME}Entity")
#set($NOT_FOUND_EXCEPTION = "${NAME}NotFoundException")
#set($REPOSITORY_TYPE = "${NAME}Repository")
#set($REPOSITORY_VARIABLE = "${NAME_LOWER}Repository")

import org.springframework.stereotype.Service;
import ${PACKAGE_NAME}.exception.${NAME_LOWER}.${NOT_FOUND_EXCEPTION};
import ${PACKAGE_NAME}.entity.${MODEL};
import ${PACKAGE_NAME}.repository.${REPOSITORY_TYPE};

import java.util.List;
import java.util.Optional;


@Service
public class ${NAME}Service{

    private final ${REPOSITORY_TYPE} ${REPOSITORY_VARIABLE};

    public ${NAME}Service(${REPOSITORY_TYPE} ${REPOSITORY_VARIABLE}) {
        this.${REPOSITORY_VARIABLE} = ${REPOSITORY_VARIABLE};
    }

    public List<${MODEL}> get${NAME}List() {
        return ${REPOSITORY_VARIABLE}.findAll();
    }

    public ${MODEL} get${NAME}(Long ${NAME_LOWER}Id) {
        Optional<${MODEL}> findById = ${REPOSITORY_VARIABLE}.findById(${NAME_LOWER}Id);

        if (findById.isEmpty()){
            throw  new ${NOT_FOUND_EXCEPTION}(${NAME_LOWER}Id);
        }

        return findById.get();
    }

    public ${MODEL} create${NAME}(${MODEL} ${NAME_LOWER}) {
        return ${REPOSITORY_VARIABLE}.save(${NAME_LOWER});
    }

    public ${MODEL} replace${NAME}(Long ${NAME_LOWER}Id, ${MODEL} ${NAME_LOWER}ToReplace) {
        ${NAME_LOWER}ToReplace.setId(${NAME_LOWER}Id);
        return ${REPOSITORY_VARIABLE}.save(${NAME_LOWER}ToReplace);
    }

    public void delete${NAME}(Long ${NAME_LOWER}Id) {
        if (${REPOSITORY_VARIABLE}.existsById(${NAME_LOWER}Id)){
            ${REPOSITORY_VARIABLE}.deleteById(${NAME_LOWER}Id);
        }else {
            throw new ${NOT_FOUND_EXCEPTION}(${NAME_LOWER}Id);
        }
    }
}