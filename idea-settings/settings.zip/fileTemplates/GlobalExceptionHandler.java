#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

@ControllerAdvice
public class GlobalExceptionHandler {

    private static Map<String, Object> defaultBody(Exception e) {
        return new HashMap<>() {{
            put("message", e.getMessage());
            put("timestamp", Instant.now().toEpochMilli());
        }};
    }
    
    @ExceptionHandler(ResponseStatusException.class)
    public ResponseEntity<Object> handleResponseStatusException(ResponseStatusException exception) {
        return new ResponseEntity<>(defaultBody(exception), exception.getHttpStatus());
    }
    
    @ExceptionHandler(Exception.class)
    public ResponseEntity<Object> representUnhandingException(Exception e){
        return new ResponseEntity<>(defaultBody(e), HttpStatus.INTERNAL_SERVER_ERROR);
    }

}