#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")

#set($MODEL = "${NAME}Entity")
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import ${PACKAGE_NAME}.entity.${MODEL};

@Repository
public interface ${NAME}Repository extends JpaRepository<${MODEL}, Long> {
}