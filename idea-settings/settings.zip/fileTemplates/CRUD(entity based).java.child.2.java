#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")

import org.springframework.http.HttpStatus;
import ${PACKAGE_NAME}.exception.ResponseStatusException;

public class ${NAME}NotFoundException extends ResponseStatusException {

    public ${NAME}NotFoundException(Long id) {
        super("${NAME} with id " + ("'" + id + "'") + " isn't founded.", HttpStatus.NOT_FOUND);
    }
}